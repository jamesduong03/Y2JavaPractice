package exercises;

public class TrafficLight {

}
