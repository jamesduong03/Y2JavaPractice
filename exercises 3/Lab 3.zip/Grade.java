package exercises;

public class Grade 
{
	int percentage;
	public Grade (int percentage)
	{
		this.percentage = percentage;
	}
	
	public void setPercentage (int percentage)
	{
		this.percentage = percentage;
	}
	public int getPercentage()
	{
		return this.percentage;
	}
	
	
	
}