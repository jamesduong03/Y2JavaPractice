package exercises;

import java.util.ArrayList;

public class StudentList 
{
	
	String student;
	int i = 0;
	
	public StudentList(String student)
	{
		this.student = student;
	}
	
	public static void main(String[] args)
	{
		ArrayList<Student>students = new ArrayList<Student>();
		
		
	}
}
