package exercises;

public class NumberListTest {

	public static void main(String[] args) 
	{
		
		
	}

}
